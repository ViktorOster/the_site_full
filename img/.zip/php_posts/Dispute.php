<?php

    require_once '../connection.php';

    $conn = new mysqli(host,user,password,db);
    session_start();
    $gamername  =$_SESSION["username"];
    $key = $_SESSION["key"];
    if (empty($key)){
        $query = "SELECT Game_Key FROM ongoing_game_list WHERE gamername='$gamername'";
                    
                    if ($result = $conn->query($query)) {

                        /* fetch object array */
                        while ($row = $result->fetch_row()) {
                            $_SESSION["Key"]= $row[0];
                        }

                        /* free result set */
                        $result->close();
                    }

                    /* close connection */
                    // echo $query;
                    $key = $_SESSION["Key"];
                }
    // echo $_POST["key"] ;
    
    if (mysqli_connect_error()) {
        die("Connect Error(".mysqli_connect_errno().")".mysqli_connect_error());
        } else {
        $UPDATE = "UPDATE ongoing_game_list SET dispute = 1 Where Game_Key = ?";
        $stmt = $conn->prepare($UPDATE);
        $stmt->bind_param("i",$key);
        echo $key;
        $stmt->execute();
        $stmt->close();
        }
        $conn->close();
    
    ?>