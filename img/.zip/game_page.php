<?php

require_once 'connection.php';

$conn = new mysqli(host,user,password,db);

// obtain the username of the opponent
session_start();


/* check connection */
if (mysqli_connect_errno()) {
    printf("Connect failed: %s\n", mysqli_connect_error());
    exit();}


        $key =isset($_SESSION['Key'])?$_SESSION['Key'] : null;
        $username = $_SESSION["username"];
        if (empty($key)){
                $query = "SELECT Game_Key FROM ongoing_game_list WHERE gamername='$username'";
                
                if ($result = $conn->query($query)) {

                    /* fetch object array */
                    while ($row = $result->fetch_row()) {
                        $_SESSION["Key"]= $row[0];
                    }

                    /* free result set */
                    $result->close();
                }

                /* close connection */
                $conn->close();
            }else{
                $query = "SELECT Game_Key FROM ongoing_game_list WHERE gamername='$username'";
                
                if ($result = $conn->query($query)) {

                    /* fetch object array */
                    while ($row = $result->fetch_row()) {
                        $_SESSION["Key"]= $row[0];
                    }

                    /* free result set */
                    $result->close();
                }

                /* close connection */
                // echo $query;
                $key = $_SESSION["Key"];

                $query = "SELECT gamername,gamemode,vs_type,amount,Game_Key FROM ongoing_game_list WHERE Game_Key = $key AND NOT gamername='$username'";
echo $query;
                if ($result = $conn->query($query)) {

                    /* fetch object array */
                    while ($row = $result->fetch_row()) {
                        $_SESSION["value"] = $row[0]; 
                        $_SESSION["gamemode"] = $row[1];
                        $_SESSION["vs_type"] = $row[2];
                        $_SESSION["amount"] = $row[3];
                        $_SESSION["Key"]= $row[4];
                    }

                    /* free result set */
                    $result->close();
                }

                /* close connection */
                $conn->close();
                
        }

// $SELECT_1 = "SELECT gamername From ongoing_game_list WHERE Game_Key = ? AND NOT gamername=?";
// $stmt = $conn->prepare($SELECT_1);
// $stmt->bind_param("is",$_SESSION["Key"],$_SESSION["username"]);
// $stmt->execute();
// $result = $stmt->get_result();
// $value = $result->fetch_assoc()['gamername'];
// $_SESSION["value"] = $value;
// $stmt->close();

// $SELECT_1 = "SELECT gamemode From ongoing_game_list WHERE Game_Key = ? AND NOT gamername=?";
// $stmt = $conn->prepare($SELECT_1);
// $stmt->bind_param("is",$_SESSION["Key"],$_SESSION["username"]);
// $stmt->execute();
// $result = $stmt->get_result();
// $value_1 = $result->fetch_assoc()['gamemode'];
// $_SESSION["gamemode"] = $value_1;
// $stmt->close();

// $SELECT_1 = "SELECT gamemode From ongoing_game_list WHERE Game_Key = ? AND NOT gamername=?";
// $stmt = $conn->prepare($SELECT_1);
// $stmt->bind_param("is",$_SESSION["Key"],$_SESSION["username"]);
// $stmt->execute();
// $result = $stmt->get_result();
// $value_1 = $result->fetch_assoc()['gamemode'];
// $_SESSION["gamemode"] = $value_1;
// $stmt->close();

// $SELECT_1 = "SELECT gamemode From ongoing_game_list WHERE Game_Key = ? AND NOT gamername=?";
// $stmt = $conn->prepare($SELECT_1);
// $stmt->bind_param("is",$_SESSION["Key"],$_SESSION["username"]);
// $stmt->execute();
// $result = $stmt->get_result();
// $value_1 = $result->fetch_assoc()['gamemode'];
// $_SESSION["gamemode"] = $value_1;
// $stmt->close();

?>

<html lang="en">


<head>
<meta content="text/html;charset=utf-8" http-equiv="Content-Type">
<meta content="utf-8" http-equiv="encoding">
<meta content="width=device-width, initial-scale=1.0" name="viewport">
<meta content="" name="keywords">
<meta content="" name="description">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
    integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">


<link rel="stylesheet" href="css/chat_css.css" />
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script type="text/javascript" src="js/js.js"></script>
<script type="text/javascript" src="js/chat_js.js"></script>
<link rel="stylesheet" href="css/chat_css.css" />
</head>

<body>
    <p  align="right">Hi - <?php echo $_SESSION['username'];  ?> - <a class="btn btn-primary" href="logout.php">Logout</a></p>
<div class="row justify-content-md-center">
    <div class="col-md-2"></div>
    <div class="card col-md-2" style="width: 18rem;">
        <img src="img/ava.jpg" class="card-img-top" alt="...">
        <div class="card-body text-center mt-2">
            <h5 class="card-title"><?php echo $_SESSION["username"]; ?></h5>
        </div>
    </div>
    <div class="col-md-2"></div>
    <div class="col-md-2"></div>
    <div class="card col-md-2" style="width: 18rem;">
        <img src="img/ava.jpg" class="card-img-top" alt="...">
        <div class="card-body text-center">
            <h5 class="card-title"><?php echo $_SESSION["value"]; ?></h5>
        </div>
    </div>
    <div class="col-md-2"></div>
</div>

<div class="row justify-content-center align-items-center mt-5 mb-5">
    <div class="col-md-2"></div>
    <div class="card col-md-2 align-items-center text-center">
        <form id="score" method="POST" onsubmit="myButton.disabled = true; return true;">
            <input type="text" name="score" required>
            <input id="submit_butt" type="submit" class="btn btn-danger wrn-btn" name="myButton" value="Submit" />
        </form>
    </div>
    <div class="col-md-4 text-center">
        <h5 class="card-title">Score</h5>
    </div>


    <!-- This script reffers to the server every 1s to check if the other player has confermed the score entered -->
    <div id="conf" class="card col-md-2 align-items-center text-center"></div>

    <div class="col-md-2"></div>
</div>

<div class="row justify-content-center align-items-center mt-5 mb-5">
    <div class="col-md-2"></div>

    <!-- This script reffers to the server every 1s to check if the other player has confermed the score entered -->

    <div id="conf_1" class="card col-md-2 align-items-center text-center"></div>



    <div class="col-md-4 justify-content-md-center text-center">
        <form id="Dispute" method="POST" onsubmit="dispute.disabled = true; return true;">
            <input id="Dispute_butt" type="submit" onclick="dispute(<?php echo $_SESSION['Key'] ?>)"  class="btn btn-danger wrn-btn" name="dispute" value="Dispute" />
        </form>
    </div>
    <div class="card text-center col-md-2">
        <form id="Confirm" method="POST" onsubmit="confirm.disabled = true; return true;">

            <input id="Confirm_butt" type="submit" class="btn btn-danger wrn-btn" name="confirm" value="Confirm" />
        </form>
    </div>
    <div class="col-md-2"></div>
</div>

<div class="row justify-content-center align-items-center mt-5 mb-5">
    <div class="col-md-2"></div>
    <div class="col-md-2"></div>

    <div id="conf_2" class="card col-md-4 align-items-center text-center"></div>
    <div class="col-md-2">
        <form id="terminate" method="POST">
            <input id="terminate_butt" type="submit" class="btn btn-danger wrn-btn" name="terminate"
                value="Terminate" onclick="deleteAllCookies()" />
        </form>
    </div>
    <div id="terminater" class="col-md-2"></div>
</div>



<div class="row justify-content-center align-items-center mt-5 mb-5">
    <div class="col-md-2"></div>
    <div class="col-md-2"></div>

    <div class="card col-md-4 align-items-center text-center">
        <div id="chatbox"></div>

        <form name="message" action="">
            <input id="messege" name="usermsg" type="text" id="usermsg" size="63" />
            <input name="submitmsg" type="submit" id="submitmsg" value="Send" />
        </form>
    </div>
    <div class="col-md-2">
    </div>
    <div id="terminater" class="col-md-2"></div>
</div>



</body>
<script>
var from = '<?php echo $_SESSION["username"]; ?>',
    key = <?php echo $_SESSION["Key"]; ?> ;
$(document).ready(function () {
    // from = prompt('name');
    $('form').submit(function (e) {
        $.post('php_posts/chat_insert.php', {
            messege: $('#messege').val(),
            from: from,
            key: key
        });
        $('#messege').val()
        return false;

    })
});

function load() {
    $.post('php_gets/load_chat.php', {
        key: key
    }, function (result) {
        $('#chatbox').html(result);
    });
}
setInterval(function () {
    load();
}, 1000);
</script>

</html>