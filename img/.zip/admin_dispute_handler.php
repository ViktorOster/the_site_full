<?php
session_start();
if ($_SESSION['logged_in']==FALSE)
{
    header("Location:login_admin.php");
}else{
    require_once 'connection.php';

    $conn = new mysqli(host,user,password,db);
    
    $Game_key   = $_POST['gamekey'];
    $_SESSION['gamekey'] = $_POST['gamekey'];
    $username   = $_SESSION['username'];
    $query = "SELECT gamername,score From ongoing_game_list Where Game_Key = $Game_key";
    
    $result = $conn->query($query);
    
    /* numeric array */
    $row = $result->fetch_array(MYSQLI_ASSOC);

    $gamername  = $row["gamername"];
    $score      = $row["score"];
    // echo $Game_key;
    // print '<div id="user_dialog_'.$gamername.'" class="user_dialog" title="You have chat with '.$username.'">
    //         <div style="height:400px; border:1px solid #ccc; overflow-y: scroll; margin-bottom:24px; padding:16px;" class="chat_history" data-touserid="'.$gamername.'" id="chat_history_'.$gamername.'">
    //         </div>
    //         <div class="form-group">
    //             <textarea name="chat_message_'.$gamername.'" id="chat_message_'.$gamername.'" class="form-control"></textarea>
    //         </div>
    //         <div class="form-group" align="right">
    //             <button type="button" name="send_chat" id="$gamername" class="btn btn-info send_chat" data-target="#myModal">Send</button>
    //         </div>
    //     </div>';

    ?>


<link rel="stylesheet" href="css/search_css.css" />
<script type="text/javascript" src="js/js.js"></script>
<script type="text/javascript" src="js/chat_js.js"></script>


<div class="modal-body">
    <div id="result">

    </div>
</div>

<div class="modal-header">

    <div>
        <div class="col-md-4">
            Score 1
        </div>
        <div class="col-md-8">
            img 1
        </div>
    </div>
    <div>
        <div class="col-md-4">
            Score 2
        </div>
        <div class="col-md-8">
            img 2
        </div>
    </div>
    <div>
        Your Name: <input type="text" value="<?= $_SESSION['username'] ?>" class="session-text" disabled>
    </div>
</div>

<div class="modal-footer">
    <div class="col-md-12">
        <form method='post' action="#" onsubmit="return post();" id="my_form" name="my_form">
            <div id="form-container">
                <div class="form-text">
                    <input type="text" style="display:none" id="username" name="username"
                        value="<?= $_SESSION['username'] ?>">
                    <input type="text" style="display:none" id="key" name="key" value="<?= $_SESSION['gamekey'] ?>">
                    <input type="text" name="comment" id="comment">
                </div>
                <div class="form-btn">
                    <input type="submit" value="Submit" id="btn" name="btn" />
                </div>
            </div>
        </form>
    </div>
</div>



<?php
}
?>