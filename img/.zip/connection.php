<?php 

const host='localhost';
const user='id12161617_happydov05';
const password='123456789';
const db='id12161617_test';

?>