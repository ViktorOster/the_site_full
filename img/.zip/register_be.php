<?php 
session_start();

require_once 'connection.php';

$conn = new mysqli(host,user,password,db);
if(isset($_POST['gamername'])){
    
    $uname=$_POST['gamername'];
    $password=$_POST['pass'];
    
    $sql="SELECT User FROM loginform WHERE User=?";
    $stmt_2 = $conn->prepare($sql);
    $stmt_2->bind_param("s",$uname);
    $stmt_2->execute();
    $stmt_2->bind_result($uname);
    $stmt_2->store_result();
    $rnum_2 = $stmt_2->num_rows;

    if($rnum_2==1){


            //Save some other things you might need like login key.
            // $_SESSION['login_key'] = user_login_key;
            
            header('Location: register.php');

            exit();
    } elseif ($rnum_2==0){
//Start a session.
        //........some processing
        
        $sql="INSERT INTO `loginform`(`User`, `Pass`, `admin`) VALUES (?,?,0)";
        $stmt_2 = $conn->prepare($sql);
        $stmt_2->bind_param("ss",$uname,$password);
        $stmt_2->execute();
        //After you have checked that the username is correct.
        $_SESSION['username'] = $uname;
        $_SESSION['logged_in'] = TRUE;      
        //After you have checked that the username is correct.
        header('Location: wager_page.php');
        exit();
    }else{
        echo "<script>alert('Error')</script>";
    }
        
}
?>