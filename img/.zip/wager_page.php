<?php 
    session_start();
    require_once 'connection.php';
    $conn = new mysqli(host,user,password,db);
    $gamername = $_SESSION["username"];
    $SELECT_2 = "SELECT gamername From ongoing_game_list Where gamername = ?";
    $stmt = $conn->prepare($SELECT_2);
    $stmt->bind_param('s',$gamername); 
    $stmt->execute();
    $stmt->store_result();
    $check_3 = $stmt->num_rows;
    $stmt->close();
    
    $SELECT_2 = "SELECT gamername From wager_list Where gamername = ?";
    $stmt = $conn->prepare($SELECT_2);
    $stmt->bind_param('s',$gamername); 
    $stmt->execute();
    $stmt->store_result();
    $check_4 = $stmt->num_rows;
    $stmt->close();


    

    if ($_SESSION['logged_in']==FALSE)
    {
        header("Location:lwager.000webhostapp.com/index.html");
    }elseif ($check_3 == 1){
        header("Location:https://lwager.000webhostapp.com/game_page.php");
    }elseif ($check_4 == 1){
        header("Location:https://lwager.000webhostapp.com/waiting_room.php");
    }else{
        
        
        
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta content="text/html;charset=utf-8" http-equiv="Content-Type">
    <meta content="utf-8" http-equiv="encoding">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

    <!-- Popper JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script> 


    <link rel="stylesheet" href="css/search_css.css" />
    <script type="text/javascript" src="js/js.js"></script>


</head>

<body>
    <!------ Include the above in your HEAD tag ---------->
    <section class="wager">
        <div class="row text-center mb-3">
            <div class="col-md-12">
                <span>Player Name: <?php echo $_SESSION["username"]; ?></span>   
                <p  align="right">Hi - <?php echo $_SESSION['username'];  ?> - <a class="btn btn-primary" href="logout.php">Logout</a></p>
            </div>
        </div>
        <div class="container">

            <form >
                <div class="row">
                    <div class="col-md-2 col-sm-12 p-0 mr-2 ml-2 mb-2 text-center">
                        <select class="form-control search-slt" id="gamemode" name="gamemode" required>
                            <option selected hidden value="">GameMode</option>
                            <option value="Fortnite Boxfight">Fortnite Boxfight</option>
                            <option value="Fortnite Buildfight">Fortnite Buildfight</option>
                        </select>
                    </div>
                    <div class="col-md-2 col-sm-12 p-0 mr-2 ml-2 mb-2 text-center">
                        <select class="form-control search-slt" id="vs_type" name="vs_type" required>
                            <option selected hidden value="">Vs Type</option>
                            <option value="1v1">1v1</option>
                            <option value="2v2">2v2</option>
                        </select>
                    </div>
                    <div class="col-md-2 col-sm-12 p-0 mr-2 ml-2 mb-2 text-center">
                        <select class="form-control search-slt" id="amount" name="amount" required>
                            <option selected hidden value="">Amount</option>
                            <option value="5">$5</option>
                            <option value="10">$10</option>
                            <option value="15">$15</option>
                            <option value="20">$20</option>
                        </select>
                    </div>
                    <div class="col-md-2 col-sm-12 p-0 mr-2 ml-2 mb-2 text-center">
                        <select class="form-control search-slt" id="server" name="server" required>
                            <option selected hidden value="">Server</option>
                            <option value="EU">EU</option>
                            <option value="NAE">NAE</option>
                        </select>
                    </div>

                    <div class="col-md-2 col-sm-12 p-0 mr-2 ml-2 mb-2 text-center">
                        <input  id="form_submit" type="submit" value="Submit" class="btn btn-danger wrn-btn" data-toggle="modal" data-target="#exampleModal">
                    </div>
                    
                </div>
            </form>
        </div>
    </section>
    <table class='table table-bordered'>
        <tr>
            <th>Game Mode</th><th>Number of Players</th><th>Server</th><th>Amount</th>
        </tr>
        
        <?php

            foreach($conn->query("SELECT gamemode,serverr,COUNT(*) FROM   wager_list  WHERE gamemode='Fortnite Boxfight' AND serverr='EU'") as $row) {
                echo "<tr>";
                echo "<td>" . $row['gamemode'] . "</td>";
                echo "<td>" . $row['COUNT(*)'] . "</td>";
                echo "<td>" . $row['serverr'] . "</td>";
                echo "</tr>"; 
            }

            foreach($conn->query("SELECT gamemode,serverr,COUNT(*) FROM   wager_list  WHERE gamemode='Fortnite Boxfight' AND serverr='NAE'") as $row) {
                echo "<tr>";
                echo "<td>" . $row['gamemode'] . "</td>";
                echo "<td>" . $row['COUNT(*)'] . "</td>";
                echo "<td>" . $row['serverr'] . "</td>";
                echo "</tr>"; 

            }

            foreach($conn->query("SELECT gamemode,serverr,COUNT(*) FROM   wager_list  WHERE gamemode='Fortnite Buildfight' AND serverr='EU'") as $row) {
                echo "<tr>";
                echo "<td>" . $row['gamemode'] . "</td>";
                echo "<td>" . $row['COUNT(*)'] . "</td>";
                echo "<td>" . $row['serverr'] . "</td>";
                echo "</tr>"; 

            }

            foreach($conn->query("SELECT gamemode,serverr,COUNT(*) FROM   wager_list  WHERE gamemode='Fortnite Buildfight' AND serverr='NAE'") as $row) {
                echo "<tr>";
                echo "<td>" . $row['gamemode'] . "</td>";
                echo "<td>" . $row['COUNT(*)'] . "</td>";
                echo "<td>" . $row['serverr'] . "</td>";
                echo "</tr>"; 
            }




           

        ?>
        </tbody>
    </table>

</body>

</html>
    <?php
    }
    ?>